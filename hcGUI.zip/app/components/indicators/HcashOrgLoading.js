import "style/Loading.less";

const HcashOrgLoading = ({ hidden }) => (
  <div
    className={"new-logo-animation"}
    style={{display: hidden ? "none" : "block"}}/>
);

export default HcashOrgLoading;
