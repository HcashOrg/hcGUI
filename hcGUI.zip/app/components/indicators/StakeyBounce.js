import "style/Stakey.less";

const StakeyBounce = ({center}) =>
  <div className={"stakey-bounce" + (center ? " center" : "")} />;

export default StakeyBounce;
