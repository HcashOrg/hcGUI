import StakeyBounce from "./StakeyBounce";

const StakeyBounceXs = () => <div className="stakey-bounce-xs"><StakeyBounce /></div>;

export default StakeyBounceXs;
