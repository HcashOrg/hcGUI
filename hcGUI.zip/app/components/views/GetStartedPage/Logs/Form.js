import LogsTab from "views/HelpPage/LogsTab";

export default () => (
  <div className="get-started-content-new-seed get-started-logs">
    <LogsTab />
  </div>
);
