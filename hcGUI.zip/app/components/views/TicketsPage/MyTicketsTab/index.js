const MyTickets = ({ children }) => (
  <div className="tab-card">
    {children}
  </div>
);

export default MyTickets;
