import "style/ReceivePage.less";
import "style/MiscComponents.less";

const MyTicketsPage = () => (
  <div className="tab-card">
    <div className="receive-content-nest">
      Statistics page coming soon!
    </div>
  </div>
);

export default MyTicketsPage;
