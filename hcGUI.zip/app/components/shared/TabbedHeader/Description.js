import { kidCheck } from "helpers";

const Description = props => <div className="tabbedheader-description" { ...props }/>;

export default kidCheck(Description);
