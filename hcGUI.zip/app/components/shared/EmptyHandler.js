import { showCheck } from "helpers";

const Aux = ({ children }) => children;

export default showCheck(Aux);
