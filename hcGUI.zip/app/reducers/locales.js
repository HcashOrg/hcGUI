
export default function notifications(state = {}) {
  //nothing here yet.
  return state;
}
